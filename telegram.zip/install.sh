pip install PyTelegramBotApi
python main.py